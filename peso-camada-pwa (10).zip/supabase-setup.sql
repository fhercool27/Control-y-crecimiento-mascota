-- Pega todo esto en Supabase > SQL Editor > New query > Run
-- Crea la tabla donde se guardan las camadas de cada usuario
-- y activa la seguridad: cada persona SOLO ve y edita lo suyo.

create table if not exists public.camadas (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  id         text not null,
  contenido  jsonb not null,
  actualizado timestamptz not null default now(),
  primary key (user_id, id)
);

alter table public.camadas enable row level security;

create policy "ver propias"   on public.camadas for select using (auth.uid() = user_id);
create policy "crear propias" on public.camadas for insert with check (auth.uid() = user_id);
create policy "editar propias" on public.camadas for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "borrar propias" on public.camadas for delete using (auth.uid() = user_id);
