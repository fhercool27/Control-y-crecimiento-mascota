// ============================================================
//  CONFIGURACION DE CUENTAS (Supabase)
//  Esta carpeta YA incluye los datos de tu proyecto.
//  IMPORTANTE: al subir a Netlify, sube la carpeta completa
//  con ESTE config.js (no lo reemplaces por uno vacio).
//  Clave publica (publishable): es segura de incluir en la app.
//  NUNCA pongas aqui la clave secret ni la service_role.
// ============================================================
window.SUPA = {
  url: "https://qtmtxhgxhkqyqygncoxe.supabase.co",
  key: "sb_publishable_AtvPznVDmHZlXzpeCp57yA_A2YCeYv3"
};
