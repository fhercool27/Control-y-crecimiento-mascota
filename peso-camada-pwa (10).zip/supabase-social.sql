-- ============================================================
--  SOCIAL: pegar TODO esto en Supabase > SQL Editor > New query > Run
--  Se puede ejecutar varias veces sin problema.
--  Crea: mensajes (con respuestas), reportes, administradores
--  y el espacio para guardar las imagenes (capturas).
-- ============================================================

-- 1) Mensajes y respuestas ------------------------------------
create table if not exists public.social_mensajes (
  id        uuid primary key default gen_random_uuid(),
  autor_id  uuid not null default auth.uid() references auth.users(id) on delete cascade,
  nombre    text not null check (char_length(nombre) between 1 and 40),
  texto     text not null default '' check (char_length(texto) <= 2000),
  imagenes  text[] not null default '{}' check (coalesce(array_length(imagenes,1),0) <= 3),
  parent_id uuid references public.social_mensajes(id) on delete cascade,
  creado    timestamptz not null default now(),
  check (char_length(texto) > 0 or coalesce(array_length(imagenes,1),0) > 0)
);
create index if not exists social_mensajes_creado_idx on public.social_mensajes (creado desc);
create index if not exists social_mensajes_parent_idx on public.social_mensajes (parent_id);
alter table public.social_mensajes enable row level security;

-- 2) Administradores (pueden borrar cualquier mensaje) ----------
create table if not exists public.social_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.social_admins enable row level security;
drop policy if exists "admin ve su fila" on public.social_admins;
create policy "admin ve su fila" on public.social_admins for select to authenticated using (auth.uid() = user_id);

-- 3) Reglas de los mensajes -------------------------------------
drop policy if exists "leer mensajes" on public.social_mensajes;
create policy "leer mensajes" on public.social_mensajes for select to authenticated using (true);
drop policy if exists "publicar mensajes" on public.social_mensajes;
create policy "publicar mensajes" on public.social_mensajes for insert to authenticated with check (auth.uid() = autor_id);
drop policy if exists "borrar propio o admin" on public.social_mensajes;
create policy "borrar propio o admin" on public.social_mensajes for delete to authenticated
  using (auth.uid() = autor_id or exists (select 1 from public.social_admins a where a.user_id = auth.uid()));

-- 4) Reportes de mensajes ---------------------------------------
create table if not exists public.social_reportes (
  id           uuid primary key default gen_random_uuid(),
  mensaje_id   uuid not null references public.social_mensajes(id) on delete cascade,
  reportero_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  motivo       text check (char_length(motivo) <= 200),
  creado       timestamptz not null default now(),
  unique (mensaje_id, reportero_id)
);
alter table public.social_reportes enable row level security;
drop policy if exists "reportar" on public.social_reportes;
create policy "reportar" on public.social_reportes for insert to authenticated with check (auth.uid() = reportero_id);
drop policy if exists "admin lee reportes" on public.social_reportes;
create policy "admin lee reportes" on public.social_reportes for select to authenticated
  using (exists (select 1 from public.social_admins a where a.user_id = auth.uid()));

-- 5) Espacio para imagenes (maximo 2 MB cada una) ----------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('social', 'social', true, 2097152, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "social subir" on storage.objects;
create policy "social subir" on storage.objects for insert to authenticated
  with check (bucket_id = 'social' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "social leer" on storage.objects;
create policy "social leer" on storage.objects for select to public using (bucket_id = 'social');
drop policy if exists "social borrar propio" on storage.objects;
create policy "social borrar propio" on storage.objects for delete to authenticated
  using (bucket_id = 'social' and (storage.foldername(name))[1] = auth.uid()::text);

-- 6) HAZTE ADMINISTRADOR (cambia el correo por el tuyo y ejecuta SOLO esta linea) ----
-- insert into public.social_admins (user_id) select id from auth.users where email = 'tu@correo.com' on conflict do nothing;
